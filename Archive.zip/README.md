
  # Ana Səhifə Hazırlama

  This is a code bundle for Ana Səhifə Hazırlama. The original project is available at https://www.figma.com/design/JF3pyOzODMpNTNtOmq6VOC/Ana-S%C9%99hif%C9%99-Haz%C4%B1rlama.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  